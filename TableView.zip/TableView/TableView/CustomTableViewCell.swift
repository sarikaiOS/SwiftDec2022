//
//  CustomTableViewCell.swift
//  TableView
//
//  Created by Apple on 27/12/22.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet var nameLbl: UILabel!
    @IBOutlet var emailLbl: UILabel!
    @IBOutlet var addressLbl: UILabel!
//    @IBOutlet var infoBtn: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
