//
//  SecondViewController.swift
//  FirstProject
//
//  Created by Apple on 16/12/22.
//

import UIKit

class SecondViewController: UIViewController {
    var data: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        print("In second viewDidLoad")
        print("The string data : \(data)")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("In second viewWillAppear")
        self.navigationController?.isNavigationBarHidden = true

    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("In second viewDidAppear")

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print("In second viewWillDisappear")

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("In second viewDidDisappear")

    }

    
    

    /*
    // MARK: - Navigation
    

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: - Private function
    func test() {}
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destination.
//        // Pass the selected object to the new view controller.
//    }
    // MARK: - API calls
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destination.
//        // Pass the selected object to the new view controller.
//    }
    
}
