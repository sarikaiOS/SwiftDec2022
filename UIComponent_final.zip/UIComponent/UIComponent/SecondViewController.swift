//
//  SecondViewController.swift
//  UIComponent
//
//  Created by Apple on 22/12/22.
//

import UIKit

class SecondViewController: UIViewController, UITextFieldDelegate,UITextViewDelegate {

    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    @IBOutlet var progressView: UIProgressView!
    @IBOutlet var stepper: UIStepper!
    @IBOutlet var stepperLabel: UILabel!
    @IBOutlet var datePicker: UIDatePicker!
    @IBOutlet var txtFld: UITextField!
    @IBOutlet var txtFld1: UITextField!
    @IBOutlet var txtView: UITextView!
    var datePicker1: UIDatePicker!
        
    var progressValue = 0.0
    var timer: Timer?
    var updateTimerStr = "test"
    var isTerms = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        activityIndicator = UIActivityIndicatorView()

        // Do any additional setup after loading the view.
        timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(updateProgressView), userInfo: updateTimerStr, repeats: true)
        
        datePicker1 = UIDatePicker()
        datePicker1.datePickerMode = .date
        datePicker1.preferredDatePickerStyle = .wheels
        txtFld.inputView = datePicker1
        
        txtView.text = "This is placeholder"
        txtView.textColor = .gray
        
        setToolbar()
        navigationBarItems()
        
        print(self.navigationController?.viewControllers)
    }
    
    func navigationBarItems() {
        let backBtn = UIBarButtonItem()
        backBtn.title = "Back"
        self.navigationController?.navigationItem.backBarButtonItem = backBtn
        
//        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Camera", style: .done, target: self, action: #selector(cameraBtnClicked))
        
        let cameraBtn = UIBarButtonItem(title: "Root", style: .done, target: self, action: #selector(rootBtnClicked))
        let reload =  UIBarButtonItem(title: "Reload", style: .done, target: self, action: #selector(reloadBtnClicked))
        
        self.navigationItem.rightBarButtonItems = [cameraBtn,reload]
    }
    
    @objc func rootBtnClicked() {
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    @objc func reloadBtnClicked() {
        if let controller = self.navigationController?.viewControllers {
            for controller in controller {
                if controller.isKind(of: WhiteViewController.self) {
                    self.navigationController?.popToViewController(controller, animated: true)
                }
            }
        }
    }
    
    @objc func updateProgressView() {
        if progressValue < 1 {
            progressValue += 0.1
            updateTimerStr += "\(progressValue)"
            progressView.progress = Float(progressValue)
        } else {
            timer?.invalidate()
            timer = nil
        }
        
//        let imageStr = timer?.userInfo as? String
//        print(timer?.userInfo)

    }
    @IBAction func reset(_ sender: UIButton) {
        progressView.progress = 0
        progressValue = 0.0
        
        if isTerms == false {
            // set checked mark Image
            
        } else {
            // set circle image
        }
        
        isTerms = !isTerms
    }
    
    @IBAction func startButtonClicked(_ sender: UIButton) {
        activityIndicator.startAnimating()
    }

    @IBAction func stopButtonClicked(_ sender: UIButton) {
        activityIndicator.hidesWhenStopped = true
        activityIndicator.stopAnimating()
    }
    
    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        stepperLabel.text = "\(sender.value)"
    }

    func setToolbar() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        // add done button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneClicked))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "cancel", style: .plain, target: self, action: #selector(doneClicked))

        toolbar.setItems([doneButton,spaceButton,cancel], animated: false)
        txtFld.inputAccessoryView = toolbar
    }
    
    @objc func doneClicked() {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MMM/yyyy"
        let dateStr = formatter.string(from: datePicker.date)
        txtFld.text = dateStr
        print(dateStr)
        self.view.endEditing(true)
        
    }
    
    @IBAction func datePickerValueChanged(_ sender: UIDatePicker) {
        doneClicked()
    }
    
    //MARK:- Textfeild delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // To avoid adding spcl characters to txtfld
        if textField == txtFld {
            let spclCharacter = ["#", "$", "*", "!", "(", ")"]
            for character in spclCharacter {
                if string == character {
                    print("This character is not allowed")
                    return false
                }
            }
            
            // Provide Max txtfld value
           
            let currentCharacterCount = textField.text?.count ?? 0
            if range.length + range.location > currentCharacterCount {
                return false
            }
            let newLength = currentCharacterCount + string.count - range.length
            return newLength <= 8
        }
        return true
    }
    
}

