//
//  CalculateAgeViewController.swift
//  Delegates
//
//  Created by Apple on 30/12/22.
//

import UIKit

class CalculateAgeViewController: UIViewController {
    @IBOutlet var datePicker: UIDatePicker!
    var calculatedAge = "0"
    weak var userDelegate: UpdateAge?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func dateValueChanged(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/mm/yyyy"
        calculatedAge = dateFormatter.string(from: datePicker.date)
        
        userDelegate?.updateUserAge(calculatedAge)
        self.navigationController?.popViewController(animated: true)
        
        
//        let currentDate = Date().
        
//        let calendar = Calendar.current
//        let age = calendar.dateComponents(calendar.dateComponents([.year], from: datePicker.date, to: now))
//
    }
    

}
