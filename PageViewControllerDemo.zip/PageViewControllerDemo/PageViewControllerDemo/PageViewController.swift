//
//  PageViewController.swift
//  PageViewControllerDemo
//
//  Created by Apple on 29/12/22.
//

import UIKit

class PageViewController: UIPageViewController, UIPageViewControllerDelegate, UIPageViewControllerDataSource {

    var viewControllerArr : [UIViewController] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        viewControllerArr = [self.storyboard?.instantiateViewController(identifier: "FIRST_VID") as! ViewController,
                             self.storyboard?.instantiateViewController(identifier: "INDIGO_VID") as! IndigoViewController,
                             self.storyboard?.instantiateViewController(identifier: "PURPLE_VID") as! PurpleViewController]
        
        self.dataSource = self
        self.delegate = self
        
        //Initial viewController
        self.setViewControllers([viewControllerArr[0]], direction: .forward, animated: true, completion: nil)
        
    }
    func setPageControl() {
        var pageViewAppearance = UIPageControl.appearance(whenContainedInInstancesOf: [UIPageViewController.self])
        pageViewAppearance.pageIndicatorTintColor = .white
        pageViewAppearance.currentPageIndicatorTintColor = .red
    }
  
    // MARK: - PageView Datasource
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewcontrollerIndex = viewControllerArr.index(of: viewController) else {
            return nil
        }
        let previousIndex = viewcontrollerIndex - 1
        guard previousIndex >= 0 else {
            return nil
        }
        guard viewControllerArr.count > previousIndex else {
            return nil
        }
        return viewControllerArr[previousIndex]
        
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewcontrollerIndex = viewControllerArr.index(of: viewController) else {
            return nil
        }
        let nextIndex = viewcontrollerIndex + 1
        guard viewControllerArr.count != nextIndex else {
            return nil
        }
        guard viewControllerArr.count > nextIndex else {
            return nil
        }
        return viewControllerArr[nextIndex]
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        setPageControl()
        return self.viewControllerArr.count
    }
     
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
}
