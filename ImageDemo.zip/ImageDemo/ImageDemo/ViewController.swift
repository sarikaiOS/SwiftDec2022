//
//  ViewController.swift
//  ImageDemo
//
//  Created by Apple on 29/12/22.
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    @IBOutlet var imageView: UIImageView!
    var imagePickerView = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imageView.image = UIImage(systemName: "pencil.circle.fill")
        imageView.image = UIImage(named: "superhero")
        imageView.contentMode = .scaleAspectFill
//        imageView.backgroundColor = UIColor(red: 255/255, green: <#T##CGFloat#>, blue: <#T##CGFloat#>, alpha: <#T##CGFloat#>)
        
        let pngData = imageView.image?.pngData()
        let jpegData = UIImage(named: "superhero")?.jpegData(compressionQuality: 1.0)
        
//        imageView.image = UIImage(data: <#T##Data#>)
        
    }
    
    
    @IBAction func setAlertView() {
        let alertView = UIAlertController(title: "Alert", message: "This is a simulator, no camera available", preferredStyle: .alert)
        alertView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alertView.addAction(UIAlertAction(title: "Ok", style: .default, handler: {_ in
            print("Ok btn in alert clicked")
        }))
        
        self.present(alertView, animated: true, completion: nil)
    }

    @IBAction func actionSheetView() {
        let actionSheetView = UIAlertController(title: "Select Photo", message: "Choose the picture that you want to set", preferredStyle: .actionSheet)
        actionSheetView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        actionSheetView.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.setAlertView()
        }))
        actionSheetView.addAction(UIAlertAction(title: "Saved Images", style: .default, handler: { _ in
            self.saveImageClicked()
        }))
        self.present(actionSheetView, animated: true, completion: nil)
    }

    func saveImageClicked() {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) {
            imagePickerView.delegate = self
            imagePickerView.sourceType = .photoLibrary
            imagePickerView.allowsEditing = true
            self.present(imagePickerView, animated: true, completion: nil)
        } else {
            print("No camera Available in Simulator")
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey(rawValue: UIImagePickerController.InfoKey.editedImage.rawValue)] as? UIImage {
            imageView.image = selectedImage
            dismiss(animated: true, completion: nil)
        }
    }
    
}

