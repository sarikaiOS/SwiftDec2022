//
//  TableViewController.swift
//  TableView
//
//  Created by Apple on 26/12/22.
//

import UIKit

class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0 {
            return 5
        }
        return 100
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Table_CID", for: indexPath)
        if indexPath.row % 2 == 0 {
            cell.contentView.backgroundColor = .darkGray
        }
        else {
            cell.contentView.backgroundColor = .lightText
        }
        cell.textLabel?.text = "\(indexPath.row + 1)"
        cell.detailTextLabel?.text = "This is details text"
        
        // Configure the cell...
        return cell
    }
    
    // MARK: - TableView delegate
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 150
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = self.storyboard?.instantiateViewController(identifier: "detail_VID") as! DetailViewController
        let detailsStr = "section :\(indexPath.section), row: \(indexPath.row)"
        detailVC.dataStr = detailsStr
        self.navigationController?.pushViewController(detailVC, animated: true)
        
    }

}
