import UIKit

let pi = 3.14
var name = "swift"
name = "swift class"

var title : String
title = "this is string"

var newString = String()

var i = 10
var isActive = false
print("this is the value of i:\(i)")

// Optional

var str1: String?
str1 = "has value"
//print(str1!) // Force unwrapping


// Optional binding
if let _ = str1 {
    print(str1!)
}
//else {
//    print("No Data")
//    str1 = "new value"
//}


//if let newTitle = title {
//    print(title!)
//} else {
//    print("NO Data")
//}


// Guard let

//guard let newStr = str1 else { return "" }


//Operator
// +, -, /, * %
// ==, !=, <, > <=, >=
//&&, || !
//=, +=, -=
// 0...10
// 0..<10
// ?: a==10? true: false

var i1 = 10
if i1%2 == 3 {
    
} else {
    
}


// Nested If loop
if i1 == 10 {
    
} else if i1 % 2 == 5 {
    
} else {
    
}

//Switch
switch i1%2 {
case 1:
    print("In first case")
case 5:
    print("In case second")
default:
    print("In default")
}


var city = "Pune"
switch city {
case "Pune", "Mumbai" : print("In Maharashtra")
default: print("No city selected")
}

// Cannot be used after swift 3
//
//for i1 = 0; i1<10; i1++ {
//    print
//}

for _ in 1...5 {
    print("*")
}

for i in 1...5 {
    print(i)
}

for _ in 1..<5 {
    print("*")
}

while i < 10 {
    i+=2
    //i = i+2
    print("Value of \(i)")
}

repeat {
    i+=1
} while i < 10


// Array
var arr : [Int]
var arr1 = [Int]()
var arr2 = [1,2,3]
var arr3:[Int] = []

print("Data of Array :\(arr2[0])")
arr2.append(10)
print(arr2)
arr2.insert(20, at: 0)
arr2.remove(at: 0)

for item in arr2 {
    print("Item value : \(item)")
}

for (index,item) in arr2.enumerated() {
    print("Index: \(index), Value : \(item)")
}



// Dictionary
// Key : value
// dict = ["one": 1, "two":2, "three":3]

var dict: [String:Int]
var dict1 = [String:Int]()
var dict2: [String:Int] = [:]
var dict3 = ["one": 1, "two":2, "three":3]

print(dict3["one"]!)

if let dictData = dict3["two"] {
    print(dictData)
}

dict3.updateValue(11, forKey: "Eleven")
print(dict3)

for value in dict3.values {
    if value > 10 {
        
    }
}
for keys in dict3.keys {
}

//Tuple - Group of different datatype
var tuple = (11,"one")
print(tuple.1)

var tuple1 = (firstObj: 11, secondObj: "one")
print(tuple1.firstObj)

// ENUM
enum GENDER: String {
    case male = "0"
    case female = "1"
}

//Male button is clicked
let gender = GENDER.male.rawValue
let genderStr = "M"
print(gender)


enum Country : Int {
    case India = 101
    case America = 201
    case Spain = 301
}

var person = Country.India

switch person {
case .India:
    print("Indian")
case .America:
    print("American")
case .Spain:
    print("Spanish")
//default:
//    print("Country not selected")

}

// Functions
func testFunction() {
    print("In test function")
}

func addTwoNumbers(para1: Int, para2: Int) {
    print(para1 + para2)
}

func addTwoNumber(para1: Int, para2: Int) -> Int {
    return para1 + para2
}

func addTwoNumber2(Number1 para1:Int, Number2 para2:Int) -> Int {
    return para1 + para2
}

func add(ofnumber1 num1: Int, number2 num2: Int) {
    
}
func addTwoNumber3(para1: Int, para2: Int) -> (Int,String) {
    return (para1 + para2, "Result")
}

func addTwoNumber4(_ para1: Int, _ para2: Int) -> (Int,String) {
    return (para1 + para2, "Result")
}



// Call function
print(addTwoNumbers(para1: 20, para2: 200))
print(addTwoNumber2(Number1: 10, Number2: 111))
let tupleFunction = addTwoNumber3(para1: 2, para2: 3)
print(tupleFunction.0)
add(ofnumber1: 10, number2: 20)
addTwoNumber4(20, 20)

// INOUT
var num1 = 111 // 30
var num2 = 222 // 20
var strOne = "one"
var strTwo = "two"

func swapValue(para1:inout Int, para2:inout Int) {
    let temp = para1
    para1 = para2
    para2 = temp
}

swapValue(para1: &num1, para2: &num2)
print(num1)
print(num2)


// Generic

func swapTwoValues<T>(para1:inout T, para2:inout T) {
    let temp = para1
    para1 = para2
    para2 = temp
}


swapTwoValues(para1: &num1, para2: &num2)
swapTwoValues(para1: &strOne, para2: &strTwo)

print("Integer values: \(num1), \(num2)")
print("String values: \(strOne), \(strTwo)")


//Variadic
func getNumber(num:Int...) {
    for item in num {
        print(item)
    }
}

getNumber(num: 33,55,66,88)


// Extension
extension String {
    func concatStr(str: String) -> String {
        return self + " " + str
    }
}

var extStr = "test this"
let extData = extStr.concatStr(str: "and add this")
print(extData)


// Closures
//escaping - API calls and non escaping
// Default closure - Non escaping

let addNumbers = {(para1: Int, para2: Int)-> Int in
    return para1 + para2
}

let addNumber2 :(Int, Int) -> Int = {(para1, para2) in
    return para1 + para2
}

let addNumber3 : (Int,Int) -> Int = { return $0 + $1 }

print(addNumber3(10,100))

print("This is closure : \(addNumbers(10,20))")

//Guard
func testgaurd() -> String {
    var optionalStr : String?
    optionalStr = "Optional string"
    
    guard let str = optionalStr else {return ""}
    return str
}


print(testgaurd())


// Higher Order function
// Input - array and output - array
var higherOrderArr = [10,44, 33, 68, 55]

// Filter
let filterArr = higherOrderArr.filter{($0 % 2 == 0)}
let filterArr1 = higherOrderArr.filter { (item) -> Bool in
    return item % 2 == 0
}
print(filterArr1)
print(filterArr)

// Map
let mapArr = higherOrderArr.map{$0*10}
print(mapArr)

// FlatMap
let flatInputArr = [[20,31,55,35], [54,25,86,nil]]
let flatMapArr = flatInputArr.flatMap{$0}
print(flatMapArr)

let compactArr = flatInputArr.compactMap{$0}
print(compactArr)

// Reduce
let reduceArr = higherOrderArr.reduce(10){$0 + $1}
print(reduceArr)


// Class
class Person {
    // var name: String?
    // var name: String!
    // var name: String = ""
    // var name = ""
    // var name: String = String()
    // var name = String()
    var name: String = "Abc"
}

let personObj = Person()
personObj.name = "John"

print(personObj.name)


class Student {
    var person: Person?
    var rank: Int
    init (rank:Int) {
//        self.person = person
        self.rank = rank
    }
}

let studentObj = Student(rank: 5)
studentObj.person = personObj

// optional chainning
if let name = studentObj.person?.name {
    print("Name of the student: \(name)")
} else {
    print("No student name found")
}

//print(studentObj.person?.name)

struct PersonStruct {
    var name: String = "ABC"
}

let peronStructObj = PersonStruct(name: "ABC")
let personStructObj1 = PersonStruct()
print(personStructObj1.name)


// Obj of class
let newPersonClassObj = Person()
newPersonClassObj.name = "A"

let oldPersonClassObj = newPersonClassObj
oldPersonClassObj.name = "B"
newPersonClassObj.name = "C"
print(newPersonClassObj.name) // B


// Obj of Structure
let newPersonStructObj = PersonStruct(name: "A")
var oldPersonStructObj = newPersonStructObj
oldPersonStructObj.name = "B"
//newPersonStructObj.name = "B"

print(newPersonStructObj.name) // B


// Properties
// Compute property and stored property

class Rectangle {
    var w : Int = 20
    var h : Int = 30
//    var area : Int {
//        return w * h
//    }
    
    var area: Int {
        get {
            return w * h
        }
        set {
            if newValue > 1000 {
                w = w / 2
            }
        }
    }
}

let rectObj = Rectangle()
print(rectObj.area) // 600
rectObj.area = 1500
print(rectObj.w) // 10
print(rectObj.area) // 300


// Property Observers
// didSet and will Set
// Getter and setter

class StepCounter {
    var totalStep: Int = 0 {
        willSet(newTotalSteps) {
            print("About to set totalSteps to \(newTotalSteps)")
        }
        didSet{
            if totalStep > oldValue {
                print("Added \(totalStep - oldValue) steps")
            }
        }
    }
}

let stepCounterObj = StepCounter()
stepCounterObj.totalStep = 200
stepCounterObj.totalStep = 700
stepCounterObj.totalStep = 900
