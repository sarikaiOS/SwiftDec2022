//
//  NavigationViewController.swift
//  UIComponent
//
//  Created by Apple on 26/12/22.
//

import UIKit

class NavigationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Navigation Bar"
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    override func viewDidDisappear(_ animated: Bool) {
//        self.title = "Back"
    }
    

    
     //MARK: - Navigation

//     In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//         Get the new view controller using segue.destination.
//         Pass the selected object to the new view controller.
        if segue.identifier == "Navigation_SID" {
            let firstVC = segue.destination as? ViewController
            firstVC?.dataStr = "This is from Cart"
        }
        
    }
    

    
    // MARK: - Navigation bar functions
    
    @IBAction func cartBtnClicked() {
        
    }
    
    @IBAction func wishListBtnClicked(_ sender: UIBarButtonItem) {
        
    }
    
    @IBAction func profileBtnClicked() {
        let VC = self.storyboard?.instantiateViewController(identifier: "VID") as? ViewController
        VC?.dataStr = "This is from profile"
        self.navigationController?.pushViewController(VC!, animated: true)
    }
    
}
