//
//  CustomTableViewController.swift
//  TableView
//
//  Created by Apple on 27/12/22.
//

import UIKit

class CustomTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    

    @IBOutlet var customTableView: UITableView!
    
    var nameArr = ["Amol", "Priya", "Jay", "Vijay"]
    var addressArr = ["Pune", "Mumbai", "Nashik", "Nagpur"]
    var infoArr = ["Pune", "Mumbai", "Nashik", "Nagpur"]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        customTableView.delegate = self
        customTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "custom_CID", for: indexPath) as! CustomTableViewCell
        cell.nameLbl.text = nameArr[indexPath.row]
        cell.emailLbl.text = "\(nameArr[indexPath.row].lowercased())@gmail.com"
        cell.addressLbl.text = addressArr[indexPath.row]
        cell.addressLbl.tag = indexPath.row
//        cell.infoBtn.addTarget(<#T##target: Any?##Any?#>, action: <#T##Selector#>, for: <#T##UIControl.Event#>)
//        cell.infoBtn.tag = indexPath.row
        return cell
    }
    
    func likeBtnClicked(_ sender: UIButton) {
        print(infoArr[sender.tag])
//        customTableView.rel
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 250
        }
        return 85
        
    }

}
