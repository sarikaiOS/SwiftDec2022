//
//  ViewController.swift
//  UIComponent
//
//  Created by Apple on 20/12/22.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var descriptionlabel: UILabel!
    @IBOutlet weak var readMoreButton: UIButton!
    @IBOutlet weak var picker: UIPickerView!
    
    var addDescriptionButton: UIButton!
    let pickerArr = ["Pune", "Mumbai", "Nagpur"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        addDescriptionButton = UIButton(frame: CGRect(x: readMoreButton.frame.origin.x,
                                                          y: readMoreButton.frame.origin.y + readMoreButton.frame.size.height + 40,
                                                          width: readMoreButton.frame.width,
                                                          height: readMoreButton.frame.height))
        
        addDescriptionButton.backgroundColor = UIColor.white
        addDescriptionButton.setTitle("Add description", for: .normal)
        addDescriptionButton.setTitleColor(.black, for: .normal)
        
        // Add action to description button
        addDescriptionButton.addTarget(self, action: #selector(addDescriptionButtonClicked), for: .touchUpInside)
        self.view.addSubview(addDescriptionButton)
    }
    
    @objc func addDescriptionButtonClicked() {
        print("Add Description button clicked")
    }

    @IBAction func readMoreButtonClicked(_ sender: UIButton) {
        print("User clicked read more button")
        descriptionlabel.text = "User did read the description"
       
    }
    
    
    @IBAction func segmentControlValueChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            print("First segment clicked")
        case 1:
            print("First segment clicked")
        default:
            print("third or forth segment clicked")
        }
    }
    
    
    @IBAction func sliderValueChanged(_ sender: Any) {
        let slider = sender as! UISlider
        print(slider.value)
    }
    
    @IBAction func SwitchValueChanged(_ sender: UISwitch) {
        if sender.isOn {
            print("The user ready")
        } else {
            print("The user is not ready")
        }
    }
    
    
    //MARK:- UIPicker Datasource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerArr.count
    }
    
    //MARK:- UIPicker Delegates
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return "Still to set"
        } else {
            return pickerArr[row]
        }
    }
}

