//
//  CustomCollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Apple on 28/12/22.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
 
    @IBOutlet var numberLbl : UILabel!
}
