//
//  UserResponse.swift
//  NSUrlSessionDemo
//
//  Created by Sarika Thakur on 17/02/19.
//  Copyright © 2019 Sarika Thakur. All rights reserved.
//

import Foundation

struct UserResponse
{
    var firstName : String?
    var lastName : String?
    var image : String?
    
}

//struct data
//{
//
//}

struct userResponseDecoder : Codable {
    
    var first_name : String?
    var lastName : String?
    var image : String?
    
    enum CodingKeys : String, CodingKey {
        case first_name
        case lastName = "last_name"
        case image = "avatar"
    }
    
}

struct jsonMainData : Decodable
{
    var page : Int?
    var per_page : Int?
    var total : Int?
    var data : [userResponseDecoder]?
}
