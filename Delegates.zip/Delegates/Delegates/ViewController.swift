//
//  ViewController.swift
//  Delegates
//
//  Created by Apple on 30/12/22.
//

// POP -

@objc protocol UpdateAge {
    @objc optional func updateUserAge(_ ageString: String)
}
//
//protocol popProtocol {
//    func showData(_string: String)
//}
//protocol OopsProtocol {
//    func showOopsData(_string: String)
//}
//
//struct POPstructure, POPstructure, OopsProtocol {
//
//}


import UIKit

class ViewController: UIViewController, UITableViewDelegate, UpdateAge {
    
    @IBOutlet var dateTxtFld: UITextField!


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calculateAgeClicked(_ sender: UIButton) {
//        tableView.delagate = self
        let calculateAgeVC = self.storyboard?.instantiateViewController(identifier: "CALCULATE_AGE_VID") as! CalculateAgeViewController
        
        calculateAgeVC.userDelegate = self
        self.navigationController?.pushViewController(calculateAgeVC, animated: true)
    }
    
    func updateUserAge(_ ageString: String) {
        dateTxtFld.text = ageString
    }

}

/*
// Basic of swift
- Optional - value/Nil = ?
- Optional unwrapping->  Optional("data") -> If let or gaurd let
- Generic <T>
- inout -
 - tuples - (10, "data")
 - enums -
 - varadic
 
 
 
 
 
*/
