//
//  ViewController.swift
//  FirstProject
//
//  Created by Apple on 13/12/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("In first viewDidLoad")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("In first viewWillAppear")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("In first viewDidAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print("In first viewWillDisappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("In first viewDidDisappear")
    }

    @IBAction func clickNextScreen(_ sender: Any) {
        let secondVC = self.storyboard?.instantiateViewController(identifier: "VID_SECOND") as! SecondViewController
        secondVC.data = "This is coming from first Viewcontroller"
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
}

