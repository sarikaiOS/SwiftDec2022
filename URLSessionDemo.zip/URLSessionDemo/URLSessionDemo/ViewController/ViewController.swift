//
//  ViewController.swift
//  URLSessionDemo
//
//  Created by Apple on 05/01/23.
//

import UIKit

class ViewController: UIViewController {

    var userDataArr: [UserResponse] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        if checkNetwork()
            {
//            getAPI()
            postAPI()

        }
        else{
            print("No internet connection")
        }
    }

    func checkNetwork() -> Bool
    {
        let reach = Reachability.forInternetConnection()

        if reach!.isReachableViaWiFi() || reach!.isReachableViaWWAN() {
            return true
        } else {
            return false
        }
    }

    // Get Method
    func getAPI()
    {
        let URLStr = URL(string: "https://reqres.in/api/users?page=2")
        let sessionCongfig = URLSession.shared
    
        let task = sessionCongfig.dataTask(with: URLStr!) { (data, response, error) in
            
            if let data = data
            {
                do
                {
//                    let jsonData = try JSONSerialization.jsonObject(with: data, options: []) as? [String : Any]
//                    let arrData = jsonData!["data"] as! [[String: Any]]
//
//                    for userData in arrData
//                    {
//
//                        print(userData["first_name"])
//                        var userResponseData = UserResponse(
//                            firstName: userData["first_name"] as! String,
//                            lastName: userData["last_name"] as! String,
//                            image: userData["avatar"] as! String)
//
////                        var userResponseData = UserResponse(firstName:userData["first_name"] as! String, lastName: userData["last_name"] as! String, image: userData["avatar"] as! String)
////                        print(userData["last_name"] as? String)
////                        print(userData["first_name"] as? String)
////                        print(userData["id"] as? Int)
//
//                        self.userDataArr.append(userResponseData)
//
//                    }
//                    print(self.userDataArr)
                    // DECODER
                    
                    let mainData = try! JSONDecoder().decode(jsonMainData.self, from: data)
                    print(mainData.data?.first?.first_name)
                   

                }
                catch
                {

                }
            }
            
        }
        task.resume()
    }
    
    
    func postAPI ()
    {
        // URLRequest
        
        let URLStr = URL(string: "https://reqres.in/api/users")
//        let dict = ["name":"XYZ", "job":"Developer"]
        var request = URLRequest(url: URLStr!)

        do
        {
            let sendData = UserRequest(name: "ABC", job: "Tester")
            let jsonData = try! jsonEncode.encode(sendData)

//            let postJsonData = try JSONSerialization.data(withJSONObject: dict, options: [])
            request.httpMethod = "POST"
            request.httpBody = jsonData
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        catch{}
        
        let session = URLSession.shared.dataTask(with: request) { (data, resp, err) in
            if let data = data
            {
                do {
                     let responseJsonData = try JSONSerialization.jsonObject(with: data, options: [])
                    print(responseJsonData)
                }
                catch {}
            }
        }.resume()
        
    }
}






