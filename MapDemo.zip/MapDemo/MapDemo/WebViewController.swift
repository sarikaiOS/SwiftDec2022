//
//  WebViewController.swift
//  MapDemo
//
//  Created by Apple on 04/01/23.
//

import UIKit
import WebKit

class WebViewController: UIViewController {

    @IBOutlet var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let url = URL(string: "https://www.latlong.net/place/london-the-uk-14153.html")
        let requestObj = URLRequest(url: url!)
        webView.load(requestObj)
    }
    

    
}
