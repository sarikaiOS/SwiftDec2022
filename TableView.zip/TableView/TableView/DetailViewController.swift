//
//  DetailViewController.swift
//  TableView
//
//  Created by Apple on 27/12/22.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet var detailLbl: UILabel!
    var dataStr = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        detailLbl.text = dataStr
        
    }
    



}
