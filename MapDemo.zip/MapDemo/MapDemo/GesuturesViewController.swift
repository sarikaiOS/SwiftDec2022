//
//  GesuturesViewController.swift
//  MapDemo
//
//  Created by Apple on 04/01/23.
//

import UIKit

class GesuturesViewController: UIViewController {

    @IBOutlet var viewForGesture: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let tapGestureRecogniser = UITapGestureRecognizer(target: self, action: #selector(handleTap(sender:)))
        tapGestureRecogniser.numberOfTapsRequired = 2
        viewForGesture.addGestureRecognizer(tapGestureRecogniser)
        
        let rotationGestureRecogniser = UIRotationGestureRecognizer(target: self, action: #selector(handleRotation(sender:)))
        viewForGesture.addGestureRecognizer(rotationGestureRecogniser)

        let pinchGestureRecogniser = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(sender:)))
        viewForGesture.addGestureRecognizer(pinchGestureRecogniser)

        let panGestureRecogniser = UIPanGestureRecognizer(target: self, action: #selector(handlePan(sender:)))
        viewForGesture.addGestureRecognizer(panGestureRecogniser)

    }
 
    @objc func handleTap(sender: UITapGestureRecognizer) {
        print("View is tapped")
    }
    
    @objc func handleRotation(sender: UIRotationGestureRecognizer) {
        print("View is rotated")
        sender.view?.transform = (sender.view!.transform.rotated(by: sender.rotation))
        sender.rotation = 50
    }

    @objc func handlePinch(sender: UIPinchGestureRecognizer) {
        print("View is Pinched")
        sender.view?.transform = (sender.view!.transform.scaledBy(x: sender.scale, y: sender.scale))
        sender.scale = 1.0
    }

    @objc func handlePan(sender: UIPanGestureRecognizer) {
        print("View is Panned")
        let translation = sender.translation(in: self.view)
        sender.view?.center = CGPoint(x: (sender.view!.center.x) + translation.x, y: (sender.view!.center.y) + translation.y)
        sender.setTranslation(CGPoint.zero, in: self.view)

    }

    
}
